﻿using UnityEngine;
using System.Collections;

public class scrGhost : MonoBehaviour 
{
	public int id;
	public float speed;
	public scrUImanager manager;
	// Use this for initialization
	
	// Update is called once per frame
	void Update () {
        if (manager.game && !manager.restart)
        {
            if (!manager.pause)
            {
                transform.Translate(Vector2.up * Time.deltaTime);
                if (transform.position.y > 5)
                {
                    Remove();
                }
            }
        }
        else
        {
            Remove();
        }


	}
        
    public void Init()
    {
        
        transform.position = new Vector2 (Random.Range (-3.0f, 3.0f), -3.5f);
        speed = Random.Range (manager.speedMin, manager.speedMax);
        manager.ghostCount++;
    }
	public void Remove()
	{
        transform.position = new Vector2 (Random.Range (-3.0f, 3.0f), -3.5f);
        //manager.ghostCount--;
		manager.pool.Push (this);
	}
}
