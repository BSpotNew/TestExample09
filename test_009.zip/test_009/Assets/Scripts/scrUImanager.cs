﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class scrUImanager : MonoBehaviour 
{
	public GameObject panStart,panGame,panMenu;
    public Text uiCountGhost,uiScore;
    public bool game=true,pause=false,restart=false;
	public scrPool pool;
	public float speedMin, speedMax;
    public int ghostCount=0,score=0;
    public float timeGhost;
    float timerCreate;
	// Use this for initialization
	void Start () 
    {
		pool = GetComponent<scrPool> ();
        timerCreate = 3;
	}
	
	// Update is called once per frame
	void Update () 
    {
        if (game)
        {
            if (!pause)
            {
                uiCountGhost.text = ghostCount.ToString() + "/10";
                uiScore.text = score.ToString();
                if (timerCreate <= 0)
                {
                    restart = false;
                    if (ghostCount < 10)
                    {
                        pool.Pop();
                        timerCreate = timeGhost;
                    }
                }
                else
                    timerCreate -= Time.deltaTime;
                /* Тач райкастер
                if (Input.touchCount == 1)
                {
                    Ray ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
                    RaycastHit hit;
                    if (Physics.Raycast(ray, out hit,float.PositiveInfinity))
                    {
                        if (hit.collider.tag=="ghost")
                        {
                            score++;
                            hit.transform.GetComponent<scrGhost>().Remove();
                        }
                    }
                }
                */
                if (Input.GetMouseButtonDown(0))
                {
                    Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    RaycastHit hit;
                    if (Physics.Raycast(ray, out hit,float.PositiveInfinity))
                    {
                        if (hit.collider.tag=="ghost")
                        {
                            score++;
                            hit.transform.GetComponent<scrGhost>().Remove();
                        }
                    }
                }
            }
        }
	}

    public void GameStart()
    {
        panStart.SetActive(false);
        panGame.SetActive(true);
        game = true;
        pause = false;
        timerCreate = 3;
        ghostCount=0;
        score = 0;
    }
    public void GamePause()
    {
        pause = !pause;
        panMenu.SetActive(pause);
    }
    public void GameRestart()
    {
        pause = false;
        panMenu.SetActive(pause);
        timerCreate = 3;
        ghostCount=0;
        score = 0;
        restart = true;
    }
    public void GameEnd()
    {
        panMenu.SetActive(false);
        panGame.SetActive(false);
        panStart.SetActive(true);
        game = false;
    }
}
