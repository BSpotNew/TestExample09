﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
/*
 	пул обьектов
*/
public class scrPool : MonoBehaviour 
{
	public GameObject prefab;//глобальный префаб
	int ids = 0;
	public int Id_new{get{ids++;return ids;}}//новый ид;
	Stack<scrGhost> ghosts = new Stack<scrGhost>();//лист обьектов
    scrUImanager man;
    void Start()
    {
        man = GetComponent<scrUImanager>();
    }
	//добавление обьекта в пул
	public void Push(scrGhost obj)
	{
		obj.gameObject.SetActive (false);
		ghosts.Push (obj);
	}
	//извлечение обьекта по типу
	public scrGhost Pop()
	{
		scrGhost ghostTemp = null;
		if(ghosts.Count>0)
		{
			ghostTemp = ghosts.Pop();
            ghostTemp.Init();
			ghostTemp.gameObject.SetActive (true);
		}
		else//при отсутствии нужного обьекта в пуле создаем новый
		{
			GameObject temp = Instantiate (prefab) as GameObject;
			ghostTemp = temp.GetComponent<scrGhost> ();
            ghostTemp.id = Id_new;
            ghostTemp.manager = man;
			ghostTemp.Init();
		}
		return ghostTemp;
	}

}
